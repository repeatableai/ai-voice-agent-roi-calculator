import React from 'react';

function Companies() {
  return (
    <div>
      <h1 style={{marginBottom: '20px', fontSize: '32px', fontWeight: '600'}}>Companies</h1>
      <p style={{color: '#666', marginBottom: '30px'}}>Manage companies in your organization</p>

      <div style={{backgroundColor: 'white', padding: '30px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', textAlign: 'center'}}>
        <p style={{color: '#666', marginBottom: '20px'}}>No companies found. Add your first company to get started.</p>
        <button style={{padding: '10px 20px', backgroundColor: '#4f46e5', color: 'white', border: 'none', borderRadius: '6px', fontSize: '14px', fontWeight: '500', cursor: 'pointer'}}>
          + Add Company
        </button>
      </div>
    </div>
  );
}

export default Companies;
