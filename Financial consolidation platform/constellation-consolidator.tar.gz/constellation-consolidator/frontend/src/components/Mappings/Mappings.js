import React from 'react';

function Mappings() {
  return (
    <div>
      <h1 style={{marginBottom: '20px', fontSize: '32px', fontWeight: '600'}}>Account Mappings</h1>
      <p style={{color: '#666', marginBottom: '30px'}}>Map company accounts to your master chart of accounts with AI assistance</p>

      <div style={{backgroundColor: 'white', padding: '30px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', textAlign: 'center'}}>
        <p style={{color: '#666', marginBottom: '20px'}}>No account mappings yet. Add companies and master accounts first.</p>
        <button style={{padding: '10px 20px', backgroundColor: '#4f46e5', color: 'white', border: 'none', borderRadius: '6px', fontSize: '14px', fontWeight: '500', cursor: 'pointer'}}>
          Generate AI Mappings
        </button>
      </div>
    </div>
  );
}

export default Mappings;
