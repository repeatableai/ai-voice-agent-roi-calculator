import React from 'react';

function Reports() {
  return (
    <div>
      <h1 style={{marginBottom: '20px', fontSize: '32px', fontWeight: '600'}}>Reports</h1>
      <p style={{color: '#666', marginBottom: '30px'}}>View consolidated financial statements and reports</p>

      <div style={{backgroundColor: 'white', padding: '30px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', textAlign: 'center'}}>
        <p style={{color: '#666', marginBottom: '20px'}}>No reports available. Run a consolidation first.</p>
        <button style={{padding: '10px 20px', backgroundColor: '#4f46e5', color: 'white', border: 'none', borderRadius: '6px', fontSize: '14px', fontWeight: '500', cursor: 'pointer'}}>
          View Latest Report
        </button>
      </div>
    </div>
  );
}

export default Reports;
