import React from 'react';

function Dashboard() {
  return (
    <div>
      <h1 style={{marginBottom: '20px', fontSize: '32px', fontWeight: '600'}}>Dashboard</h1>
      <p style={{color: '#666', marginBottom: '30px'}}>Welcome to Constellation Consolidator - AI-Powered Financial Consolidation Platform</p>

      <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px', marginBottom: '30px'}}>
        <StatCard title="Total Companies" value="0" color="#4f46e5" />
        <StatCard title="Master Accounts" value="0" color="#059669" />
        <StatCard title="Account Mappings" value="0" color="#d97706" />
        <StatCard title="Consolidation Runs" value="0" color="#dc2626" />
      </div>

      <div style={{backgroundColor: 'white', padding: '30px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
        <h2 style={{marginBottom: '15px', fontSize: '20px', fontWeight: '600'}}>Getting Started</h2>
        <ul style={{listStyle: 'none', padding: 0}}>
          <li style={{padding: '12px 0', borderBottom: '1px solid #e5e7eb'}}>1. Add companies to your organization</li>
          <li style={{padding: '12px 0', borderBottom: '1px solid #e5e7eb'}}>2. Create a master chart of accounts</li>
          <li style={{padding: '12px 0', borderBottom: '1px solid #e5e7eb'}}>3. Map company accounts to master accounts (AI-powered)</li>
          <li style={{padding: '12px 0', borderBottom: '1px solid #e5e7eb'}}>4. Import transactions</li>
          <li style={{padding: '12px 0'}}>5. Run consolidation and generate reports</li>
        </ul>
      </div>
    </div>
  );
}

function StatCard({ title, value, color }) {
  return (
    <div style={{backgroundColor: 'white', padding: '24px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderLeft: `4px solid ${color}`}}>
      <div style={{fontSize: '14px', color: '#666', marginBottom: '8px'}}>{title}</div>
      <div style={{fontSize: '32px', fontWeight: '600', color: color}}>{value}</div>
    </div>
  );
}

export default Dashboard;
