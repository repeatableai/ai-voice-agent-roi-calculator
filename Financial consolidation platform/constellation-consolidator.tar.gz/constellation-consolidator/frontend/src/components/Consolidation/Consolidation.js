import React from 'react';

function Consolidation() {
  return (
    <div>
      <h1 style={{marginBottom: '20px', fontSize: '32px', fontWeight: '600'}}>Consolidation</h1>
      <p style={{color: '#666', marginBottom: '30px'}}>Run financial consolidations with automated intercompany eliminations</p>

      <div style={{backgroundColor: 'white', padding: '30px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', textAlign: 'center'}}>
        <p style={{color: '#666', marginBottom: '20px'}}>No consolidation runs yet. Complete your setup and run your first consolidation.</p>
        <button style={{padding: '10px 20px', backgroundColor: '#4f46e5', color: 'white', border: 'none', borderRadius: '6px', fontSize: '14px', fontWeight: '500', cursor: 'pointer'}}>
          New Consolidation Run
        </button>
      </div>
    </div>
  );
}

export default Consolidation;
