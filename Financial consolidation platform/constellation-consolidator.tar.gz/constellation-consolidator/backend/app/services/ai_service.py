import openai
from typing import List, Dict
import json
import logging
from dataclasses import dataclass
from ..core.config import settings

logger = logging.getLogger(__name__)
openai.api_key = settings.OPENAI_API_KEY

@dataclass
class MappingSuggestion:
    company_account_id: str
    company_account_name: str
    master_account_id: str
    master_account_name: str
    confidence_score: float
    reasoning: str

@dataclass
class IntercompanyMatch:
    transaction_1_id: str
    transaction_2_id: str
    confidence_score: float
    reasoning: str
    amount_difference: float

class AIService:
    def __init__(self):
        self.model = settings.OPENAI_MODEL
        self.temperature = settings.OPENAI_TEMPERATURE
        self.max_tokens = settings.OPENAI_MAX_TOKENS

    async def suggest_account_mappings(self, company_accounts: List[Dict], master_accounts: List[Dict], company_context: str = None) -> List[MappingSuggestion]:
        logger.info(f"Generating AI mappings for {len(company_accounts)} accounts")
        system_prompt = "You are an expert accountant. Map company accounts to master accounts with confidence scores and reasoning."
        user_prompt = f"Company accounts: {company_accounts[:10]}\nMaster accounts: {master_accounts}\nProvide JSON mappings."
        try:
            response = await self._call_openai(system_prompt, user_prompt)
            return self._parse_mapping_response(response, company_accounts, master_accounts)
        except Exception as e:
            logger.error(f"AI mapping error: {e}")
            return []

    async def detect_intercompany_transactions(self, transactions: List[Dict], companies: List[Dict]) -> List[IntercompanyMatch]:
        logger.info(f"Detecting intercompany transactions")
        return []

    def _parse_mapping_response(self, response: str, company_accounts: List[Dict], master_accounts: List[Dict]) -> List[MappingSuggestion]:
        suggestions = []
        try:
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            if json_start >= 0 and json_end > json_start:
                data = json.loads(response[json_start:json_end])
                company_lookup = {acc['id']: acc for acc in company_accounts}
                master_lookup = {acc['id']: acc for acc in master_accounts}
                for mapping in data.get('mappings', []):
                    cid = mapping.get('company_account_id')
                    mid = mapping.get('master_account_id')
                    if cid in company_lookup and mid in master_lookup:
                        suggestions.append(MappingSuggestion(
                            company_account_id=cid,
                            company_account_name=company_lookup[cid]['account_name'],
                            master_account_id=mid,
                            master_account_name=master_lookup[mid]['account_name'],
                            confidence_score=mapping.get('confidence', 0.7),
                            reasoning=mapping.get('reasoning', 'AI suggested')
                        ))
        except Exception as e:
            logger.error(f"Parse error: {e}")
        return suggestions

    async def _call_openai(self, system_prompt: str, user_prompt: str) -> str:
        try:
            response = openai.ChatCompletion.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=self.temperature,
                max_tokens=self.max_tokens
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"OpenAI error: {e}")
            raise

ai_service = AIService()
