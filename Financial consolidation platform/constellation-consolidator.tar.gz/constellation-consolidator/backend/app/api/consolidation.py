from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from ..core.database import get_db
from ..core.security import get_current_user
from ..models.user import User
from ..models.consolidation import ConsolidationRun, Organization
from ..services.consolidation_engine import get_consolidation_engine

router = APIRouter()

class ConsolidationRequest(BaseModel):
    organization_id: str
    fiscal_year: int
    fiscal_period: int
    period_end_date: datetime
    company_ids: Optional[List[str]] = None
    run_name: Optional[str] = None

class ConsolidationResponse(BaseModel):
    id: str
    organization_id: str
    run_name: str
    fiscal_year: int
    fiscal_period: int
    status: str
    total_assets: Optional[float]
    total_revenue: Optional[float]
    net_income: Optional[float]
    created_at: datetime
    class Config:
        from_attributes = True

@router.post("/run", response_model=ConsolidationResponse, status_code=201)
async def run_consolidation(request: ConsolidationRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    org = db.query(Organization).filter(Organization.id == request.organization_id, Organization.owner_id == current_user.id).first()
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    engine = get_consolidation_engine(db)
    try:
        consolidation_run = await engine.run_consolidation(
            organization_id=request.organization_id,
            fiscal_year=request.fiscal_year,
            fiscal_period=request.fiscal_period,
            period_end_date=request.period_end_date,
            company_ids=request.company_ids,
            run_name=request.run_name,
            created_by=current_user.id
        )
        return ConsolidationResponse.from_orm(consolidation_run)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Consolidation failed: {str(e)}")

@router.get("/runs", response_model=List[ConsolidationResponse])
async def list_runs(organization_id: str, limit: int = 50, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    runs = db.query(ConsolidationRun).join(Organization).filter(
        ConsolidationRun.organization_id == organization_id,
        Organization.owner_id == current_user.id
    ).order_by(ConsolidationRun.created_at.desc()).limit(limit).all()
    return [ConsolidationResponse.from_orm(r) for r in runs]
