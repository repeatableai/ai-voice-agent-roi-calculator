from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List
from datetime import datetime
from ..core.database import get_db
from ..core.security import get_current_user
from ..models.user import User
from ..models.consolidation import Transaction

router = APIRouter()

class TransactionCreate(BaseModel):
    company_id: str
    account_id: str
    transaction_date: datetime
    description: str
    debit_amount: float = 0.0
    credit_amount: float = 0.0

class TransactionResponse(BaseModel):
    id: str
    company_id: str
    transaction_date: datetime
    debit_amount: float
    credit_amount: float
    class Config:
        from_attributes = True

@router.post("/", response_model=TransactionResponse, status_code=201)
async def create_transaction(txn_data: TransactionCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    transaction = Transaction(**txn_data.dict())
    db.add(transaction)
    db.commit()
    db.refresh(transaction)
    return TransactionResponse.from_orm(transaction)

@router.get("/company/{company_id}", response_model=List[TransactionResponse])
async def list_transactions(company_id: str, limit: int = 100, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    transactions = db.query(Transaction).filter(Transaction.company_id == company_id).limit(limit).all()
    return [TransactionResponse.from_orm(t) for t in transactions]
